       <!DOCTYPE html>
       <html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl' : 'ltr'); ?>">

       <head>
           <meta charset="UTF-8">
           <title>Bright Solution</title>
           <meta name="description" content="<?php echo e(__('Bright Solution')); ?>">
           <meta name="keywords" content="">
           <meta name="author" content="">
           <!-- Mobile Specific Meta -->
           <meta name="viewport" content="width=device-width, initial-scale=1">

           <!-- Favicon -->
           <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('style/assets/img/logo/fav.png')); ?>">

           <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/owl.carousel.css')); ?>">

           <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/fontawesome-all.css')); ?>">
           <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/animate.css')); ?>">
           <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/flaticon.css')); ?>">
           <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/bootstrap.min.css')); ?>">
           <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/video.min.css')); ?>">
           <?php if(app()->getLocale() === 'ar'): ?>
               <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/style-ar.css')); ?>">
           <?php else: ?>
               <link rel="stylesheet" href="<?php echo e(asset('style/assets/css/style-en.css')); ?>">
           <?php endif; ?>
       </head>

       <body class="nio-con" id="body">
           <div id="preloader"></div>
           <div class="up">
               <a href="#" class="scrollup text-center"><i class="fas fa-chevron-up"></i></a>
           </div>

           <!-- Start of header section
 ============================================= -->
           <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

           <!-- End of header section
 ============================================= -->
           <!-- Start of content section
 ============================================= -->

           <?php echo $__env->yieldContent('content'); ?>

           <!-- End of content section
 ============================================= -->

           <!-- Start of footer section
============================================= -->
           <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

           <!-- End of footer section
 ============================================= -->


           <!-- For Js Library -->
           <script src="<?php echo e(asset('style/assets/js/jquery.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/bootstrap.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/popper.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/owl.carousel.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/jarallax.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/jquery.magnific-popup.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/appear.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/Chart.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/utils.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/wow.min.js')); ?>  "></script>
           <script src="<?php echo e(asset('style/assets/js/jquery.filterizr.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/circle-progress.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/jquery.counterup.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/waypoints.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/parallax-scroll.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/tilt.jquery.min.js')); ?>"></script>
           <script src="<?php echo e(asset('style/assets/js/script.js')); ?>"></script>
       </body>

       </html>
<?php /**PATH D:\xampp_8.2\htdocs\bright_solutionz\resources\views/layouts/app.blade.php ENDPATH**/ ?>