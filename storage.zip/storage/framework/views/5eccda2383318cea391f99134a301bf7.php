<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\xampp_8.2\htdocs\bright_solutionz\vendor\filament\forms\src\/../resources/views/components/rich-editor/toolbar/group.blade.php ENDPATH**/ ?>