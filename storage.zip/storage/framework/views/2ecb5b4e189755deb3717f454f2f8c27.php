

<?php $__env->startSection('content'); ?>
    <!-- Start of Banner section
                                                                                 ============================================= -->
    <section id="nio-con-slider" class="nio-con-slider-section position-relative">
        <span class="slider-shape slider-sh1  position-absolute" data-parallax='{"y" : 100, "rotateY":500}'><img
                src="<?php echo e(asset('style/assets/img/shape/abs.png')); ?>" alt=""></span>
        <span class="slider-shape slider-sh2 position-absolute" data-parallax='{"y" : 150}'><img
                src="<?php echo e(asset('style/assets/img/shape/abs1.png')); ?>" alt=""></span>
        <span class="slider-shape slider-sh3 position-absolute" data-parallax='{"y" : -150}'><img
                src="<?php echo e(asset('style/assets/img/shape/abs2.png')); ?> " alt=""></span>
        <span class="slider-shape slider-sh4 position-absolute"><img src="<?php echo e(asset('style/assets/img/shape/s-sh1.png')); ?>"
                alt=""></span>
        <span class="slider-shape slider-sh5 position-absolute" data-parallax='{"x" : 150}'><img
                src="<?php echo e(asset('style/assets/img/shape/s-sh2.png')); ?>" alt=""></span>
        <div id="nio-con-slider-id" class="nio-con-main-slider">
            <div class="nio-con-slider-item position-relative">
                <div class="background_overlay"></div>
                <div class="slider-main-img img-zooming" data-background="<?php echo e(asset('style/assets/img/slider/s1.jpg')); ?>">
                </div>
                <div class="slider-text-wrap">
                    <div class="container">
                        <div class="slider-text-area headline text-center pera-content">
                            <span><?php echo __('Empowering Your Growth'); ?></span>
                            <h1> <?php echo __('Elevating Your Efficiency'); ?></h1>
                            <div class="slider-btn">
                                <a href="#nio-con-about"><?php echo __('ABOUT US'); ?></a>
                                <a href="#nio-con-service"><?php echo __('OUR SERVICES'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="nio-con-slider-item position-relative">
                <div class="background_overlay"></div>
                <div class="slider-main-img img-zooming" data-background="<?php echo e(asset('style/assets/img/slider/s2.jpg')); ?> ">
                </div>
                <div class="slider-text-wrap">
                    <div class="container">
                        <div class="slider-text-area headline text-center pera-content">
                            <span> <?php echo e(__('We connect ambition with opportunity, driven by compliance.')); ?></span>
                            <h1> <?php echo e(__('And guided by a clear vision')); ?></h1>
                            <div class="slider-btn">
                                <a href="#nio-con-about"><?php echo __('ABOUT US'); ?></a>
                                <a href="#nio-con-service"><?php echo __('OUR SERVICES'); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </section>
    <!-- End of Banner section
    ============================================= -->

    <!-- Start of about section
     ============================================= -->
    <section id="nio-con-about" class="nio-con-about-section">
        <div class="container">
            <div class="nio-con-about-content position-relative">
                <span class="nio-con-about-circle position-absolute"><img src="assets/img/shape/ab-c.png"
                        alt=""></span>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="nio-con-about-img position-relative wow fadeInLeft" data-wow-delay="0ms"
                            data-wow-duration="1500ms">
                            <img src="<?php echo e(asset('style/assets/img/about/ab1.jpg')); ?>" alt="">
                            <div class="nio-con-about-counter headline">
                                <h3><?php echo __('Empowering Your Growth'); ?></h3>
                                <h4><?php echo __('Elevating Your Efficiency'); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="nio-con-about-text wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="nio-con-section-title headline">
                                <h2><?php echo __('About Us'); ?></h2>
                                <span><?php echo __($aboutUs->title) ?? ''; ?></span>

                            </div>
                            <div class="nio-con-about-details">
                                <?php echo __($aboutUs->description) ?? ''; ?>

                            </div>
                            <div class="nio-con-about-list clearfix ul-li">
                                <ul>
                                    <li>
                                        <span><?php echo e(__('Our Vision')); ?></span>
                                        <?php echo __($aboutUs->vision) ?? ''; ?>

                                    </li>
                                    <li>
                                        <span> <?php echo e(__('Our Mission')); ?> </span>
                                        <?php echo __($aboutUs->mission) ?? ''; ?>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of About section
                                                                                 ============================================= -->

    <!-- Start of special feature section
                                                                                 ============================================= -->
    <section id="nio-con-spccial-feature" class="nio-con-spccial-feature-section position-relative">
        <span class="sf-deco-shape deco-shape-1 position-absolute" data-parallax='{"y" : 40}'><img
                src="assets/img/shape/abs3.png" alt=""></span>
        <span class="sf-deco-shape deco-shape-2 position-absolute" data-parallax='{"y" : 140}'><img
                src="assets/img/shape/abs4.png" alt=""></span>
        <span class="sf-deco-shape deco-shape-3 position-absolute"><img src="<?php echo e(asset('assets/img/shape/abs5.png')); ?>"
                alt=""></span>
        <div class="container">
            <div class="nio-con-spccial-feature-content">
                <div class="row justify-content-center">
                    <?php if($ourValues->isNotEmpty()): ?>
                        <?php $__currentLoopData = $ourValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="nio-con-spccial-feature-innerbox position-relative wow fadeInUp"
                                    data-wow-delay="<?php echo e($index * 300); ?>ms" data-wow-duration="1500ms">
                                    <div class="nio-con-spccial-feature-icon">
                                        <img src="<?php echo e(asset('storage/' . $value->image)); ?>"
                                            alt="<?php echo e(__('Our Values') . __($value->title) ?? ''); ?>">
                                    </div>
                                    <div class="nio-con-spccial-feature-text headline pera-content">
                                        <h3> <?php echo __($value->title) ?? ''; ?></h3>
                                        <p> <?php echo __($value->description) ?? ''; ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-12 text-center">
                            <p><?php echo e(__('No values found.')); ?></p>
                        </div>
                    <?php endif; ?>



                </div>
            </div>
        </div>
    </section>
    <!-- End of specia feature section
                                                                                 ============================================= -->

    <!-- Start of Service section
                                                                                 ============================================= -->
    <section id="nio-con-service" class="nio-con-service-section position-relative">
        <span class="ser-shape position-absolute" data-parallax='{"y" : -50}'><img
                src="<?php echo e(asset('style/assets/img/shape/s-sh3.png')); ?>" alt=""></span>
        <div class="container">
            <div class="nio-con-section-title text-center headline">
                <span><?php echo e(__('OUR SERVICES')); ?></span>
                <h2><?php echo e(__('Services we provide')); ?></h2>
            </div>
            <div class="nio-con-service-content">
                <div class="row">
                    <?php if($ourServices->isNotEmpty()): ?>
                        <?php $__currentLoopData = $ourServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6">
                                <div class="nio-con-service-img-text wow fadeInUp" data-wow-delay="<?php echo e($index * 300); ?>ms"
                                    data-wow-duration="1500ms">
                                    <div class="nio-con-service-img position-relative">
                                        <div class="nio-con-service-img-wrap">
                                            <img src="<?php echo e(asset('storage/' . $service->image)); ?>"
                                                alt="<?php echo e(__('Our Services') . __($value->title) ?? ''); ?>">
                                        </div>
                                        <div class="nio-con-service-icon-txt headline">
                                            <div class="nio-con-service-icon">
                                                <img src="<?php echo e(asset('style/assets/img/icon/ser-icon1.png')); ?>"
                                                    alt="">
                                            </div>
                                            <h3><?php echo __($service->title) ?? ''; ?></h3>
                                        </div>
                                        <div class="nio-con-service-middle position-absolute">
                                            <h3><?php echo __($service->title) ?? ''; ?></h3>
                                        </div>
                                    </div>
                                    <div class="nio-con-service-text pera-content position-relative">
                                        <?php echo __($service->description) ?? ''; ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-12 text-center">
                            <p><?php echo e(__('No values found.')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <!-- End of service section
                                                                                 ============================================= -->

    <!-- Start of Portfolio section
                                                                                 ============================================= -->
    <section id="nio-con-portfolio" class="nio-con-portfolio-section position-relative"
        data-background="<?php echo e(asset('style/assets/img/bg/port-bg.jpg')); ?> ">
        <span class="pr-shape port-shape1 position-absolute"><img src="<?php echo e(asset('style/assets/img/shape/p-sh1.png')); ?>"
                alt=""></span>
        <span class="pr-shape port-shape2 position-absolute"><img src="<?php echo e(asset('style/assets/img/shape/p-sh2.png')); ?>"
                alt=""></span>
        <div class="background_overlay"></div>
        <div class="container">
            <div class="nio-con-portfolio-top">
                <div class="row">
                    <div class="col-md-12">
                        <div class="nio-con-section-title headline">
                            <h2><?php echo e(__('Why Bright Solutionz?')); ?></h2>
                            <span>"<?php echo e(__('Simplified process, hassle-free experience')); ?>"</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="nio-con-portfolio-content">
            <div id="nio-con-portfolio-slider" class="nio-con-portfolio-silder-area">
                <?php if($ourServices->isNotEmpty()): ?>
                    <?php $__currentLoopData = $whyUs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="nio-con-portfolio-innerbox position-relative">
                            <div class="nio-con-portfolio-img">
                                <img src="<?php echo e(asset('storage/' . $item->image)); ?>"
                                    alt="<?php echo e(__('Why Us') . __($item->title)); ?>">
                            </div>
                            <div class="nio-con-portfolio-text headline">
                                <span> <?php echo __($item->description) ?? ''; ?></span>
                                <h3> <?php echo __($item->description) ?? ''; ?></h3>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-12 text-center">
                        <p><?php echo e(__('No values found.')); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- End of Portfolio section
                                                                                 ============================================= -->

    <!-- Start of why choose section
                                                                                 ============================================= -->
    <section id="nio-con-why-choose" class="nio-con-why-choose-section position-relative">
        <span class="wh-circle-shape position-absolute"><img src="<?php echo e(asset('style/assets/img/shape/wh-circle.png')); ?>"
                alt=""></span>
        <div class="container">
            <div class="nio-con-why-choose-content">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="nio-con-why-choose-main-img position-relative wow fadeInLeft" data-wow-delay="0ms"
                            data-wow-duration="1500ms">
                            <span class="nio-con-wh-shape position-absolute nio-con-wh-sh1"><img
                                    src="<?php echo e(asset('style/assets/img/shape/wh-shape.png')); ?>" alt=""></span>
                            <span class="nio-con-wh-shape position-absolute nio-con-wh-sh2"><img
                                    src="<?php echo e(asset('style/assets/img/shape/wh-shape1.png')); ?>" alt=""></span>
                            <span class="nio-con-wh-shape position-absolute nio-con-wh-sh3"><img
                                    src="<?php echo e(asset('style/assets/img/shape/wh-shape2.png')); ?>" alt=""></span>
                            <div class="nio-con-why-choose-img">
                                <img src="<?php echo e(asset('style/assets/img/about/wh1.jpg')); ?>" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="nio-con-why-choose-text">
                            <div class="nio-con-section-title headline">
                                <span>"<?php echo e(__("We don't just support your operations, we enhance your strategy.")); ?>"</span>
                                <h2><?php echo e(__('Strategic Advantages')); ?></h2>
                            </div>
                            <div class="nio-con-why-choose-list">
                                <div class="row">
                                    <?php if($strategyAdvantages->isNotEmpty()): ?>
                                        <?php $__currentLoopData = $strategyAdvantages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $advantage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <div class="nio-con-wh-icon-text wow fadeInUp"
                                                    data-wow-delay="<?php echo e($index * 200); ?>ms" data-wow-duration="1500ms">
                                                    <div class="nio-con-wh-icon">
                                                        <img src="<?php echo e(asset('storage/' . $advantage->image)); ?>"
                                                            alt="<?php echo e(__('Strategic Advantages') . __($advantage->title) ?? ''); ?>">
                                                    </div>
                                                    <div class="nio-con-wh-text headline pera-content">
                                                        <h3><?php echo __($advantage->title) ?? ''; ?>

                                                        </h3>
                                                        <p><?php echo __($advantage->description) ?? ''; ?>

                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <div class="col-12 text-center">
                                            <p><?php echo e(__('No values found.')); ?></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End of why choose section
                                                                                 ============================================= -->

    <section id="nio-con-spccial-clients" class="nio-con-spccial-feature-section2 position-relative">
        <div class="container">
            <div class="nio-con-portfolio-top">
                <div class="row">
                    <div class="col-md-12">
                        <div class="nio-con-section-title headline">
                            <h2><?php echo e(__('OUR CLIENTS')); ?> </h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="nio-con-spccial-feature-content">
                <div class="row justify-content-center">
                    <?php if($clients->isNotEmpty()): ?>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="nio-con-spccial-feature-innerbox position-relative wow fadeInUp"
                                    data-wow-delay="<?php echo e($index * 300); ?>ms" data-wow-duration="1500ms">
                                    <div class="nio-con-spccial-feature-icon">
                                        <img src="<?php echo e(asset('storage/' . $client->image)); ?>"
                                            alt="<?php echo e(__('OUR CLIENTS') . __($client->title)); ?>">
                                    </div>
                                    <div class="nio-con-spccial-feature-text headline pera-content">
                                        <h3><?php echo e(__($client->title) ?? ''); ?></h3>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-12 text-center">
                            <p><?php echo e(__('No clients found.')); ?></p>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp_8.2\htdocs\bright_solutionz\resources\views/home.blade.php ENDPATH**/ ?>