<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH D:\xampp_8.2\htdocs\bright_solutionz\vendor\filament\forms\src\/../resources/views/components/grid.blade.php ENDPATH**/ ?>